<?php

class AutoContentAIPro_ImageHandler {
    
    private $openrouter_api;
    private $logger;
    
    public function __construct() {
        $this->openrouter_api = new AutoContentAIPro_OpenRouterAPI();
        $this->logger = new AutoContentAIPro_Logger();
    }
    
    public function get_featured_image($topic) {
        // Try AI image generation first
        $image_url = $this->generate_ai_image($topic);
        
        if ($image_url) {
            $this->logger->log('image_generation', "AI-generated image for topic: {$topic}", 'success');
            return $image_url;
        }
        
        $this->logger->log('image_generation', "Failed to generate AI image for topic: {$topic}", 'warning');
        return null;
    }
    
    private function generate_ai_image($topic) {
        // Create image generation prompt
        $prompt = $this->create_image_prompt($topic);
        
        // Try different AI providers for image generation
        $image_url = $this->try_dall_e_generation($prompt);
        if ($image_url) return $image_url;
        
        $image_url = $this->try_flux_generation($prompt);
        if ($image_url) return $image_url;
        
        return null;
    }
    
    private function create_image_prompt($topic) {
        return "Create a professional, high-quality featured image for an article about '{$topic}'. The image should be visually appealing, relevant to the topic, and suitable for a blog post. Style: modern, clean, engaging.";
    }
    
    private function try_dall_e_generation($prompt) {
        try {
            $response = $this->openrouter_api->generate_image($prompt, 'dall-e-3');
            if (isset($response['url'])) {
                return $response['url'];
            }
        } catch (Exception $e) {
            $this->logger->log('image_generation', 'DALL-E error: ' . $e->getMessage(), 'warning');
        }
        return null;
    }
    
    private function try_flux_generation($prompt) {
        try {
            $response = $this->openrouter_api->generate_image($prompt, 'flux');
            if (isset($response['url'])) {
                return $response['url'];
            }
        } catch (Exception $e) {
            $this->logger->log('image_generation', 'Flux error: ' . $e->getMessage(), 'warning');
        }
        return null;
    }
    
    public function upload_image_from_url($image_url, $post_id) {
        if (empty($image_url)) {
            return false;
        }
        
        // Download image
        $ch = curl_init();
        curl_setopt_array($ch, array(
            CURLOPT_URL => $image_url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_USERAGENT => 'AutoContent AI Pro/1.0'
        ));
        
        $image_data = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);
        
        if ($error || $http_code !== 200 || !$image_data) {
            $this->logger->log('image_generation', 'Failed to download image: ' . ($error ?: "HTTP {$http_code}"), 'error');
            return false;
        }
        
        // Generate filename
        $filename = 'autocontent-' . $post_id . '-' . time() . '.jpg';
        
        // Upload to WordPress
        $upload = wp_upload_bits($filename, null, $image_data);
        
        if ($upload['error']) {
            $this->logger->log('image_generation', 'Upload error: ' . $upload['error'], 'error');
            return false;
        }
        
        // Create attachment
        $attachment = array(
            'post_mime_type' => 'image/jpeg',
            'post_title' => sanitize_file_name($filename),
            'post_content' => '',
            'post_status' => 'inherit'
        );
        
        $attachment_id = wp_insert_attachment($attachment, $upload['file'], $post_id);
        
        if (is_wp_error($attachment_id)) {
            $this->logger->log('image_generation', 'Attachment creation error: ' . $attachment_id->get_error_message(), 'error');
            return false;
        }
        
        // Generate metadata
        require_once(ABSPATH . 'wp-admin/includes/image.php');
        $attachment_data = wp_generate_attachment_metadata($attachment_id, $upload['file']);
        wp_update_attachment_metadata($attachment_id, $attachment_data);
        
        return $attachment_id;
    }
}
