<?php

class AutoContentAIPro_SEOOptimizer {
    
    private $logger;
    
    public function __construct() {
        $this->logger = new AutoContentAIPro_Logger();
    }
    
    public function optimize_post($post_id, $focus_keyword, $content_data) {
        try {
            // Set RankMath focus keyword if RankMath is active
            $this->set_rankmath_focus_keyword($post_id, $focus_keyword);
            
            // Set meta description
            $this->set_meta_description($post_id, $content_data);
            
            // Add internal and external links
            $this->add_internal_links($post_id);
            $this->add_external_links($post_id, $focus_keyword);
            
            // Optimize content structure
            $this->optimize_content_structure($post_id, $focus_keyword);
            
            $this->logger->log('seo_optimization', "SEO optimization completed for post {$post_id}", 'success');
            
        } catch (Exception $e) {
            $this->logger->log('seo_optimization', "SEO optimization failed: " . $e->getMessage(), 'error');
        }
    }
    
    private function set_rankmath_focus_keyword($post_id, $focus_keyword) {
        if (class_exists('RankMath')) {
            update_post_meta($post_id, 'rank_math_focus_keyword', $focus_keyword);
            update_post_meta($post_id, 'rank_math_pillar_content', 'off');
            
            $this->logger->log('seo_optimization', "RankMath focus keyword set: {$focus_keyword}", 'success');
        } else {
            // Fallback for other SEO plugins or custom implementation
            update_post_meta($post_id, '_autocontent_focus_keyword', $focus_keyword);
        }
    }
    
    private function set_meta_description($post_id, $content_data) {
        $meta_description = isset($content_data['meta_description']) ? $content_data['meta_description'] : '';
        
        if (empty($meta_description) && isset($content_data['excerpt'])) {
            $meta_description = substr($content_data['excerpt'], 0, 160);
        }
        
        if ($meta_description) {
            // RankMath meta description
            if (class_exists('RankMath')) {
                update_post_meta($post_id, 'rank_math_description', $meta_description);
            }
            
            // Yoast SEO meta description
            if (class_exists('WPSEO_Options')) {
                update_post_meta($post_id, '_yoast_wpseo_metadesc', $meta_description);
            }
            
            // Generic meta description
            update_post_meta($post_id, '_autocontent_meta_description', $meta_description);
        }
    }
    
    private function add_internal_links($post_id) {
        $internal_links_count = get_option('autocontent_ai_pro_internal_links_count', 2);
        
        if ($internal_links_count <= 0) {
            return;
        }
        
        // Get related posts for internal linking
        $post = get_post($post_id);
        $related_posts = $this->get_related_posts($post, $internal_links_count);
        
        if (empty($related_posts)) {
            return;
        }
        
        $content = $post->post_content;
        $link_count = 0;
        
        foreach ($related_posts as $related_post) {
            if ($link_count >= $internal_links_count) {
                break;
            }
            
            $link_text = $related_post->post_title;
            $link_url = get_permalink($related_post->ID);
            $link_html = '<a href="' . esc_url($link_url) . '">' . esc_html($link_text) . '</a>';
            
            // Replace [INTERNAL_LINK] placeholder or add at the end of first paragraph
            if (strpos($content, '[INTERNAL_LINK]') !== false) {
                $content = preg_replace('/\[INTERNAL_LINK\]/', $link_html, $content, 1);
            } else {
                $content = $this->insert_link_in_content($content, $link_html);
            }
            
            $link_count++;
        }
        
        // Update post content
        wp_update_post(array(
            'ID' => $post_id,
            'post_content' => $content
        ));
        
        $this->logger->log('seo_optimization', "Added {$link_count} internal links to post {$post_id}", 'success');
    }
    
    private function add_external_links($post_id, $focus_keyword) {
        $external_links_count = get_option('autocontent_ai_pro_external_links_count', 3);
        
        if ($external_links_count <= 0) {
            return;
        }
        
        $external_links = $this->get_external_links($focus_keyword, $external_links_count);
        
        if (empty($external_links)) {
            return;
        }
        
        $post = get_post($post_id);
        $content = $post->post_content;
        $link_count = 0;
        
        foreach ($external_links as $link) {
            if ($link_count >= $external_links_count) {
                break;
            }
            
            $link_html = '<a href="' . esc_url($link['url']) . '" target="_blank" rel="noopener">' . esc_html($link['text']) . '</a>';
            
            // Replace [EXTERNAL_LINK] placeholder or add at appropriate location
            if (strpos($content, '[EXTERNAL_LINK]') !== false) {
                $content = preg_replace('/\[EXTERNAL_LINK\]/', $link_html, $content, 1);
            } else {
                $content = $this->insert_link_in_content($content, $link_html);
            }
            
            $link_count++;
        }
        
        // Update post content
        wp_update_post(array(
            'ID' => $post_id,
            'post_content' => $content
        ));
        
        $this->logger->log('seo_optimization', "Added {$link_count} external links to post {$post_id}", 'success');
    }
    
    private function get_related_posts($post, $limit = 5) {
        $args = array(
            'post_type' => 'post',
            'post_status' => 'publish',
            'posts_per_page' => $limit,
            'post__not_in' => array($post->ID),
            'orderby' => 'rand'
        );
        
        // Try to find posts with similar categories
        $categories = wp_get_post_categories($post->ID);
        if (!empty($categories)) {
            $args['category__in'] = $categories;
        }
        
        $related_posts = get_posts($args);
        
        // If no category-related posts, get random posts
        if (empty($related_posts)) {
            unset($args['category__in']);
            $related_posts = get_posts($args);
        }
        
        return $related_posts;
    }
    
    private function get_external_links($keyword, $count) {
        // This is a simplified implementation
        // In a real scenario, you might want to use APIs or databases of authoritative sources
        $authoritative_domains = array(
            'wikipedia.org',
            'britannica.com',
            'nationalgeographic.com',
            'smithsonianmag.com',
            'bbc.com',
            'cnn.com',
            'reuters.com'
        );
        
        $links = array();
        $search_terms = explode(' ', $keyword);
        
        for ($i = 0; $i < $count && $i < count($authoritative_domains); $i++) {
            $domain = $authoritative_domains[$i];
            $search_term = isset($search_terms[$i]) ? $search_terms[$i] : $keyword;
            
            $links[] = array(
                'url' => 'https://' . $domain . '/wiki/' . urlencode($search_term),
                'text' => 'Learn more about ' . $search_term
            );
        }
        
        return $links;
    }
    
    private function insert_link_in_content($content, $link_html) {
        // Find the end of the first paragraph
        $paragraphs = explode('</p>', $content);
        
        if (count($paragraphs) > 1) {
            $paragraphs[0] .= ' ' . $link_html . '</p>';
            return implode('</p>', $paragraphs);
        }
        
        // If no paragraphs found, append to content
        return $content . ' ' . $link_html;
    }
    
    private function optimize_content_structure($post_id, $focus_keyword) {
        $post = get_post($post_id);
        $content = $post->post_content;
        
        // Ensure focus keyword appears in first paragraph
        if (strpos(strtolower($content), strtolower($focus_keyword)) === false) {
            $content = $this->add_keyword_to_first_paragraph($content, $focus_keyword);
        }
        
        // Update post content
        wp_update_post(array(
            'ID' => $post_id,
            'post_content' => $content
        ));
    }
    
    private function add_keyword_to_first_paragraph($content, $keyword) {
        $paragraphs = explode('</p>', $content);
        
        if (!empty($paragraphs[0])) {
            $first_paragraph = $paragraphs[0];
            
            // Add keyword naturally to the first paragraph
            if (strpos(strtolower($first_paragraph), strtolower($keyword)) === false) {
                $first_paragraph .= ' This article covers everything you need to know about ' . $keyword . '.';
            }
            
            $paragraphs[0] = $first_paragraph;
            return implode('</p>', $paragraphs);
        }
        
        return $content;
    }
}
