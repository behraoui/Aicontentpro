<?php

class AutoContentAIPro_OpenRouterAPI {
    
    private $api_keys;
    private $logger;
    private $api_endpoints = array(
        'openrouter' => 'https://openrouter.ai/api/v1',
        'openai' => 'https://api.openai.com/v1',
        'claude' => 'https://api.anthropic.com/v1',
        'deepseek' => 'https://api.deepseek.com/v1'
    );
    
    public function __construct() {
        $this->api_keys = array(
            'openrouter' => get_option('autocontent_ai_pro_openrouter_api_key', ''),
            'openai' => get_option('autocontent_ai_pro_openai_api_key', ''),
            'claude' => get_option('autocontent_ai_pro_claude_api_key', ''),
            'deepseek' => get_option('autocontent_ai_pro_deepseek_api_key', '')
        );
        $this->logger = new AutoContentAIPro_Logger();
    }
    
    public function generate_content($prompt, $model = null) {
        if (!$model) {
            $model = get_option('autocontent_ai_pro_default_model', 'openai/gpt-4');
        }
        
        // Determine which API provider to use based on model
        $provider = $this->get_provider_from_model($model);
        
        if (empty($this->api_keys[$provider])) {
            return array('error' => ucfirst($provider) . ' API key not configured');
        }
        
        // Build request based on provider
        $request_data = $this->build_request($provider, $model, $prompt);
        $endpoint = $this->api_endpoints[$provider] . $request_data['endpoint'];
        
        $response = $this->make_api_request($endpoint, $request_data['data'], $provider);
        
        if (isset($response['error'])) {
            $this->logger->log($provider . '_api', 'API Error: ' . $response['error'], 'error');
            return $response;
        }
        
        // Parse response based on provider
        $content = $this->parse_response($response, $provider);
        
        if ($content) {
            $this->logger->log($provider . '_api', 'Content generated successfully', 'success');
            return array('content' => $content);
        }
        
        return array('error' => 'Unexpected API response format');
    }
    
    private function get_provider_from_model($model) {
        if (strpos($model, 'gpt-') === 0 || strpos($model, 'openai/') === 0) {
            return 'openai';
        } elseif (strpos($model, 'claude') !== false || strpos($model, 'anthropic/') === 0) {
            return 'claude';
        } elseif (strpos($model, 'deepseek') !== false) {
            return 'deepseek';
        } else {
            return 'openrouter';
        }
    }
    
    private function build_request($provider, $model, $prompt) {
        $system_message = 'You are a professional content writer and SEO expert. Create high-quality, engaging, and SEO-optimized content.';
        
        switch ($provider) {
            case 'openai':
                return array(
                    'endpoint' => '/chat/completions',
                    'data' => array(
                        'model' => str_replace('openai/', '', $model),
                        'messages' => array(
                            array('role' => 'system', 'content' => $system_message),
                            array('role' => 'user', 'content' => $prompt)
                        ),
                        'max_tokens' => 4000,
                        'temperature' => 0.7
                    )
                );
                
            case 'claude':
                return array(
                    'endpoint' => '/messages',
                    'data' => array(
                        'model' => str_replace('anthropic/', '', $model),
                        'system' => $system_message,
                        'messages' => array(
                            array('role' => 'user', 'content' => $prompt)
                        ),
                        'max_tokens' => 4000,
                        'temperature' => 0.7
                    )
                );
                
            case 'deepseek':
                return array(
                    'endpoint' => '/chat/completions',
                    'data' => array(
                        'model' => $model,
                        'messages' => array(
                            array('role' => 'system', 'content' => $system_message),
                            array('role' => 'user', 'content' => $prompt)
                        ),
                        'max_tokens' => 4000,
                        'temperature' => 0.7
                    )
                );
                
            default: // openrouter
                return array(
                    'endpoint' => '/chat/completions',
                    'data' => array(
                        'model' => $model,
                        'messages' => array(
                            array('role' => 'system', 'content' => $system_message),
                            array('role' => 'user', 'content' => $prompt)
                        ),
                        'max_tokens' => 4000,
                        'temperature' => 0.7
                    )
                );
        }
    }
    
    private function parse_response($response, $provider) {
        switch ($provider) {
            case 'openai':
            case 'deepseek':
            case 'openrouter':
                return isset($response['choices'][0]['message']['content']) ? 
                    $response['choices'][0]['message']['content'] : null;
                
            case 'claude':
                return isset($response['content'][0]['text']) ? 
                    $response['content'][0]['text'] : null;
                
            default:
                return null;
        }
    }
    
    private function make_api_request($endpoint, $data, $provider) {
        $headers = $this->build_headers($provider);
        if (isset($headers['error'])) {
            return $headers;
        }
        
        $ch = curl_init();
        curl_setopt_array($ch, array(
            CURLOPT_URL => $endpoint,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => json_encode($data),
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_TIMEOUT => 60,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_USERAGENT => 'AutoContent AI Pro/1.0'
        ));
        
        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);
        
        if ($error) {
            return array('error' => 'cURL Error: ' . $error);
        }
        
        if ($http_code !== 200) {
            $error_message = "HTTP Error {$http_code}";
            if ($response) {
                $decoded = json_decode($response, true);
                if (isset($decoded['error']['message'])) {
                    $error_message .= ': ' . $decoded['error']['message'];
                }
            }
            return array('error' => $error_message);
        }
        
        $decoded_response = json_decode($response, true);
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            return array('error' => 'Invalid JSON response from API');
        }
        
        return $decoded_response;
    }
    
    private function build_headers($provider) {
        $api_key = $this->api_keys[$provider];
        
        if (empty($api_key)) {
            return array('error' => ucfirst($provider) . ' API key not configured');
        }
        
        switch ($provider) {
            case 'openai':
                return array(
                    'Authorization: Bearer ' . $api_key,
                    'Content-Type: application/json'
                );
                
            case 'claude':
                return array(
                    'Authorization: Bearer ' . $api_key,
                    'Content-Type: application/json',
                    'x-api-version: 2023-06-01'
                );
                
            case 'deepseek':
                return array(
                    'Authorization: Bearer ' . $api_key,
                    'Content-Type: application/json'
                );
                
            default: // openrouter
                return array(
                    'Authorization: Bearer ' . $api_key,
                    'Content-Type: application/json',
                    'HTTP-Referer: ' . home_url(),
                    'X-Title: AutoContent AI Pro WordPress Plugin'
                );
        }
    }
    
    public function test_connection() {
        $test_prompt = "Write a simple test message to verify the API connection.";
        $response = $this->generate_content($test_prompt);
        
        if (isset($response['error'])) {
            return array(
                'success' => false,
                'message' => $response['error']
            );
        }
        
        return array(
            'success' => true,
            'message' => 'API connection successful'
        );
    }
    
    public function generate_image($prompt, $model = 'dall-e-3') {
        // Determine which provider supports image generation
        if (strpos($model, 'dall-e') !== false) {
            return $this->generate_openai_image($prompt, $model);
        } else {
            return $this->generate_openrouter_image($prompt, $model);
        }
    }
    
    private function generate_openai_image($prompt, $model) {
        if (empty($this->api_keys['openai'])) {
            return array('error' => 'OpenAI API key not configured for image generation');
        }
        
        $endpoint = $this->api_endpoints['openai'] . '/images/generations';
        
        $data = array(
            'model' => $model,
            'prompt' => $prompt,
            'n' => 1,
            'size' => '1024x1024',
            'quality' => 'standard'
        );
        
        $headers = array(
            'Authorization: Bearer ' . $this->api_keys['openai'],
            'Content-Type: application/json'
        );
        
        $response = $this->make_image_request($endpoint, $data, $headers);
        
        if (isset($response['data'][0]['url'])) {
            return array('url' => $response['data'][0]['url']);
        }
        
        return array('error' => 'Failed to generate image with OpenAI');
    }
    
    private function generate_openrouter_image($prompt, $model) {
        if (empty($this->api_keys['openrouter'])) {
            return array('error' => 'OpenRouter API key not configured for image generation');
        }
        
        $endpoint = $this->api_endpoints['openrouter'] . '/images/generations';
        
        $data = array(
            'model' => $model,
            'prompt' => $prompt,
            'n' => 1,
            'size' => '1024x1024'
        );
        
        $headers = array(
            'Authorization: Bearer ' . $this->api_keys['openrouter'],
            'Content-Type: application/json',
            'HTTP-Referer: ' . home_url(),
            'X-Title: AutoContent AI Pro WordPress Plugin'
        );
        
        $response = $this->make_image_request($endpoint, $data, $headers);
        
        if (isset($response['data'][0]['url'])) {
            return array('url' => $response['data'][0]['url']);
        }
        
        return array('error' => 'Failed to generate image with OpenRouter');
    }
    
    private function make_image_request($endpoint, $data, $headers) {
        $ch = curl_init();
        curl_setopt_array($ch, array(
            CURLOPT_URL => $endpoint,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => json_encode($data),
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_TIMEOUT => 60,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_USERAGENT => 'AutoContent AI Pro/1.0'
        ));
        
        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);
        
        if ($error) {
            return array('error' => 'cURL Error: ' . $error);
        }
        
        if ($http_code !== 200) {
            $error_message = "HTTP Error {$http_code}";
            if ($response) {
                $decoded = json_decode($response, true);
                if (isset($decoded['error']['message'])) {
                    $error_message .= ': ' . $decoded['error']['message'];
                }
            }
            return array('error' => $error_message);
        }
        
        $decoded_response = json_decode($response, true);
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            return array('error' => 'Invalid JSON response from API');
        }
        
        return $decoded_response;
    }
    
    public function get_available_provider() {
        // Return the first available API provider
        foreach ($this->api_keys as $provider => $key) {
            if (!empty($key)) {
                return $provider;
            }
        }
        return null;
    }
    
    public function has_any_api_configured() {
        foreach ($this->api_keys as $key) {
            if (!empty($key)) {
                return true;
            }
        }
        return false;
    }
}
