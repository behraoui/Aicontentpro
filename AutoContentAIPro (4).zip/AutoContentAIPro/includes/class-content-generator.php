<?php

class AutoContentAIPro_ContentGenerator {
    
    private $openrouter_api;
    private $image_handler;
    private $seo_optimizer;
    private $logger;
    
    public function __construct() {
        $this->openrouter_api = new AutoContentAIPro_OpenRouterAPI();
        $this->image_handler = new AutoContentAIPro_ImageHandler();
        $this->seo_optimizer = new AutoContentAIPro_SEOOptimizer();
        $this->logger = new AutoContentAIPro_Logger();
    }
    
    public function generate_single_article($topic, $focus_keyword, $publish_status = 'draft') {
        $this->logger->log('content_generation', "Starting content generation for topic: {$topic}", 'info');
        
        try {
            // Check if any API is configured
            if (!$this->openrouter_api->has_any_api_configured()) {
                throw new Exception('No API keys configured. Please configure at least one AI provider (OpenAI, Claude, DeepSeek, or OpenRouter) in settings.');
            }
            
            // Generate article content
            $content_data = $this->generate_article_content($topic, $focus_keyword);
            
            if (!$content_data || isset($content_data['error'])) {
                throw new Exception($content_data['error'] ?? 'Failed to generate content');
            }
            
            // Create WordPress post
            $post_data = array(
                'post_title' => $content_data['title'],
                'post_content' => $content_data['content'],
                'post_status' => $publish_status,
                'post_author' => get_current_user_id(),
                'post_type' => 'post',
                'post_excerpt' => $content_data['excerpt']
            );
            
            // Create URL slug from title
            $post_data['post_name'] = sanitize_title($content_data['title']);
            
            $post_id = wp_insert_post($post_data);
            
            if (is_wp_error($post_id)) {
                throw new Exception('Failed to create WordPress post: ' . $post_id->get_error_message());
            }
            
            // Add featured image if enabled
            if (get_option('autocontent_ai_pro_enable_images', 1)) {
                $this->add_featured_image($post_id, $topic);
            }
            
            // Apply SEO optimization if enabled
            if (get_option('autocontent_ai_pro_enable_seo', 1)) {
                $this->seo_optimizer->optimize_post($post_id, $focus_keyword, $content_data);
            }
            
            $this->logger->log('content_generation', "Successfully generated article with ID: {$post_id}", 'success');
            
            return array(
                'success' => true,
                'post_id' => $post_id,
                'title' => $content_data['title'],
                'message' => __('Article generated successfully!', 'autocontent-ai-pro')
            );
            
        } catch (Exception $e) {
            $this->logger->log('content_generation', "Error generating article: " . $e->getMessage(), 'error');
            return array(
                'success' => false,
                'error' => $e->getMessage()
            );
        }
    }
    
    private function generate_article_content($topic, $focus_keyword) {
        $prompt = $this->build_content_prompt($topic, $focus_keyword);
        
        $response = $this->openrouter_api->generate_content($prompt);
        
        if (!$response || isset($response['error'])) {
            return array('error' => $response['error'] ?? 'Failed to generate content from API');
        }
        
        return $this->parse_api_response($response['content']);
    }
    
    private function build_content_prompt($topic, $focus_keyword) {
        $internal_links = get_option('autocontent_ai_pro_internal_links_count', 2);
        $external_links = get_option('autocontent_ai_pro_external_links_count', 3);
        
        $prompt = "Write a comprehensive, SEO-optimized article about '{$topic}' with the focus keyword '{$focus_keyword}'. 

Requirements:
1. Create an engaging title that includes the focus keyword
2. Write a compelling meta description (150-160 characters) that includes the focus keyword
3. Structure the article with proper H2 and H3 headings that incorporate the focus keyword naturally
4. Write 1000-1500 words of high-quality, informative content
5. Include {$internal_links} placeholders for internal links marked as [INTERNAL_LINK]
6. Include {$external_links} placeholders for external links marked as [EXTERNAL_LINK]
7. Write a brief excerpt (150 words) for the article
8. Use natural keyword density without keyword stuffing

Format your response as JSON with the following structure:
{
  \"title\": \"Article title here\",
  \"meta_description\": \"Meta description here\",
  \"excerpt\": \"Article excerpt here\",
  \"content\": \"Full article content with HTML formatting\"
}

Make sure the content is original, engaging, and provides real value to readers.";

        return $prompt;
    }
    
    private function parse_api_response($content) {
        // Try to parse JSON response
        $parsed = json_decode($content, true);
        
        if ($parsed && isset($parsed['title']) && isset($parsed['content'])) {
            return $parsed;
        }
        
        // Fallback: Extract content manually if JSON parsing fails
        $title = $this->extract_title_from_content($content);
        $excerpt = $this->generate_excerpt_from_content($content);
        
        return array(
            'title' => $title,
            'content' => $content,
            'excerpt' => $excerpt,
            'meta_description' => substr($excerpt, 0, 160)
        );
    }
    
    private function extract_title_from_content($content) {
        // Extract first H1 or generate from first paragraph
        if (preg_match('/<h1[^>]*>(.*?)<\/h1>/i', $content, $matches)) {
            return strip_tags($matches[1]);
        }
        
        // Extract first line as title
        $lines = explode("\n", strip_tags($content));
        return !empty($lines[0]) ? trim($lines[0]) : 'Generated Article';
    }
    
    private function generate_excerpt_from_content($content) {
        $text = strip_tags($content);
        $words = explode(' ', $text);
        $excerpt_words = array_slice($words, 0, 30);
        return implode(' ', $excerpt_words) . '...';
    }
    
    private function add_featured_image($post_id, $topic) {
        try {
            $image_url = $this->image_handler->get_featured_image($topic);
            
            if ($image_url) {
                $attachment_id = $this->image_handler->upload_image_from_url($image_url, $post_id);
                
                if ($attachment_id && !is_wp_error($attachment_id)) {
                    set_post_thumbnail($post_id, $attachment_id);
                    $this->logger->log('image_generation', "Featured image added to post {$post_id}", 'success');
                }
            }
        } catch (Exception $e) {
            $this->logger->log('image_generation', "Failed to add featured image: " . $e->getMessage(), 'error');
        }
    }
}
