<?php

class AutoContentAIPro_Logger {
    
    private $table_name;
    
    public function __construct() {
        global $wpdb;
        $this->table_name = $wpdb->prefix . 'autocontent_ai_pro_logs';
    }
    
    public function log($action, $message, $status = 'info', $data = null) {
        global $wpdb;
        
        $wpdb->insert(
            $this->table_name,
            array(
                'action' => sanitize_text_field($action),
                'message' => sanitize_text_field($message),
                'status' => sanitize_text_field($status),
                'data' => $data ? json_encode($data) : null,
                'timestamp' => current_time('mysql')
            ),
            array('%s', '%s', '%s', '%s', '%s')
        );
        
        // Clean up old logs (keep only last 1000 entries)
        $this->cleanup_old_logs();
    }
    
    public function get_logs($limit = 50, $offset = 0) {
        global $wpdb;
        
        $sql = $wpdb->prepare(
            "SELECT * FROM {$this->table_name} ORDER BY timestamp DESC LIMIT %d OFFSET %d",
            $limit,
            $offset
        );
        
        return $wpdb->get_results($sql);
    }
    
    public function get_logs_by_action($action, $limit = 50) {
        global $wpdb;
        
        $sql = $wpdb->prepare(
            "SELECT * FROM {$this->table_name} WHERE action = %s ORDER BY timestamp DESC LIMIT %d",
            $action,
            $limit
        );
        
        return $wpdb->get_results($sql);
    }
    
    public function get_logs_by_status($status, $limit = 50) {
        global $wpdb;
        
        $sql = $wpdb->prepare(
            "SELECT * FROM {$this->table_name} WHERE status = %s ORDER BY timestamp DESC LIMIT %d",
            $status,
            $limit
        );
        
        return $wpdb->get_results($sql);
    }
    
    public function clear_logs() {
        global $wpdb;
        return $wpdb->query("TRUNCATE TABLE {$this->table_name}");
    }
    
    private function cleanup_old_logs() {
        global $wpdb;
        
        $count = $wpdb->get_var("SELECT COUNT(*) FROM {$this->table_name}");
        
        if ($count > 1000) {
            $wpdb->query(
                "DELETE FROM {$this->table_name} 
                 WHERE id NOT IN (
                     SELECT id FROM (
                         SELECT id FROM {$this->table_name} 
                         ORDER BY timestamp DESC LIMIT 1000
                     ) AS recent_logs
                 )"
            );
        }
    }
}
