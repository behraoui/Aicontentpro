/**
 * AutoContent AI Pro Admin Scripts
 */

(function($) {
    'use strict';

    // Main admin functionality
    var AutoContentAdmin = {
        init: function() {
            this.bindEvents();
            this.checkApiStatus();
        },

        bindEvents: function() {
            // Single article generation
            $('#single-article-form').on('submit', this.handleSingleGeneration);
            
            // Batch article generation
            $('#batch-articles-form').on('submit', this.handleBatchGeneration);
            
            // API test button
            $('#test-api').on('click', this.testApiConnection);
        },

        handleSingleGeneration: function(e) {
            e.preventDefault();
            
            var $form = $(this);
            var $button = $form.find('button[type="submit"]');
            var originalText = $button.html();
            
            // Validate form
            var topic = $('#topic').val().trim();
            var focusKeyword = $('#focus_keyword').val().trim();
            
            if (!topic || !focusKeyword) {
                AutoContentAdmin.showNotification('Please fill in all required fields.', 'error');
                return;
            }
            
            // Show loading state
            $button.addClass('loading').prop('disabled', true);
            AutoContentAdmin.showProgress(0, 'Preparing to generate content...');
            
            // Prepare data
            var data = {
                action: 'generate_content',
                nonce: autocontentAjax.nonce,
                topic: topic,
                focus_keyword: focusKeyword,
                publish_status: $('#publish_status').val()
            };
            
            // Make AJAX request
            $.ajax({
                url: autocontentAjax.ajax_url,
                type: 'POST',
                data: data,
                timeout: 120000, // 2 minutes timeout
                success: function(response) {
                    if (response.success) {
                        AutoContentAdmin.showProgress(100, 'Content generated successfully!');
                        AutoContentAdmin.showResult({
                            success: true,
                            title: response.title,
                            message: response.message,
                            post_id: response.post_id
                        });
                        $form[0].reset();
                    } else {
                        AutoContentAdmin.showNotification(response.error || 'An error occurred.', 'error');
                    }
                },
                error: function(xhr, status, error) {
                    var errorMessage = 'Request failed: ' + error;
                    if (status === 'timeout') {
                        errorMessage = 'Request timed out. The content generation may still be in progress.';
                    }
                    AutoContentAdmin.showNotification(errorMessage, 'error');
                },
                complete: function() {
                    $button.removeClass('loading').prop('disabled', false).html(originalText);
                    setTimeout(function() {
                        AutoContentAdmin.hideProgress();
                    }, 3000);
                }
            });
        },

        handleBatchGeneration: function(e) {
            e.preventDefault();
            
            var $form = $(this);
            var $button = $form.find('button[type="submit"]');
            var originalText = $button.html();
            
            // Validate form
            var keywordList = $('#keyword_list').val().trim();
            
            if (!keywordList) {
                AutoContentAdmin.showNotification('Please enter at least one keyword.', 'error');
                return;
            }
            
            // Parse keywords
            var keywords = keywordList.split('\n').map(function(keyword) {
                return keyword.trim();
            }).filter(function(keyword) {
                return keyword.length > 0;
            });
            
            if (keywords.length === 0) {
                AutoContentAdmin.showNotification('Please enter valid keywords.', 'error');
                return;
            }
            
            if (keywords.length > 10) {
                AutoContentAdmin.showNotification('Maximum 10 keywords allowed for batch generation.', 'error');
                return;
            }
            
            // Show loading state
            $button.addClass('loading').prop('disabled', true);
            AutoContentAdmin.showProgress(0, 'Starting batch generation...');
            AutoContentAdmin.clearResults();
            
            // Process keywords one by one
            AutoContentAdmin.processBatchKeywords(keywords, $('#batch_publish_status').val(), 0, function() {
                $button.removeClass('loading').prop('disabled', false).html(originalText);
                $form[0].reset();
                setTimeout(function() {
                    AutoContentAdmin.hideProgress();
                }, 3000);
            });
        },

        processBatchKeywords: function(keywords, publishStatus, currentIndex, callback) {
            if (currentIndex >= keywords.length) {
                AutoContentAdmin.showProgress(100, 'Batch generation completed!');
                callback();
                return;
            }
            
            var keyword = keywords[currentIndex];
            var progress = Math.round(((currentIndex + 1) / keywords.length) * 100);
            
            AutoContentAdmin.showProgress(progress, 'Generating article ' + (currentIndex + 1) + ' of ' + keywords.length + ': ' + keyword);
            
            var data = {
                action: 'generate_content',
                nonce: autocontentAjax.nonce,
                topic: keyword,
                focus_keyword: keyword,
                publish_status: publishStatus
            };
            
            $.ajax({
                url: autocontentAjax.ajax_url,
                type: 'POST',
                data: data,
                timeout: 120000,
                success: function(response) {
                    if (response.success) {
                        AutoContentAdmin.showResult({
                            success: true,
                            title: response.title,
                            message: 'Article generated for: ' + keyword,
                            post_id: response.post_id,
                            keyword: keyword
                        });
                    } else {
                        AutoContentAdmin.showResult({
                            success: false,
                            title: 'Failed: ' + keyword,
                            message: response.error || 'An error occurred.',
                            keyword: keyword
                        });
                    }
                },
                error: function(xhr, status, error) {
                    AutoContentAdmin.showResult({
                        success: false,
                        title: 'Failed: ' + keyword,
                        message: 'Request failed: ' + error,
                        keyword: keyword
                    });
                },
                complete: function() {
                    // Process next keyword after a short delay
                    setTimeout(function() {
                        AutoContentAdmin.processBatchKeywords(keywords, publishStatus, currentIndex + 1, callback);
                    }, 1000);
                }
            });
        },

        testApiConnection: function(e) {
            e.preventDefault();
            
            var $button = $(this);
            var originalText = $button.text();
            
            $button.addClass('loading').prop('disabled', true);
            
            $.ajax({
                url: autocontentAjax.ajax_url,
                type: 'POST',
                data: {
                    action: 'test_api_connection',
                    nonce: autocontentAjax.nonce
                },
                success: function(response) {
                    if (response.success) {
                        $('#api-status').html('<div class="api-status-success">✓ API connection successful</div>');
                    } else {
                        $('#api-status').html('<div class="api-status-error">✗ API connection failed: ' + (response.error || 'Unknown error') + '</div>');
                    }
                },
                error: function() {
                    $('#api-status').html('<div class="api-status-error">✗ Failed to test API connection</div>');
                },
                complete: function() {
                    $button.removeClass('loading').prop('disabled', false).text(originalText);
                }
            });
        },

        checkApiStatus: function() {
            $.ajax({
                url: autocontentAjax.ajax_url,
                type: 'POST',
                data: {
                    action: 'check_api_status',
                    nonce: autocontentAjax.nonce
                },
                success: function(response) {
                    var configuredApis = [];
                    var missingApis = [];
                    
                    if (response.openrouter_configured) configuredApis.push('OpenRouter');
                    else missingApis.push('OpenRouter');
                    
                    if (response.openai_configured) configuredApis.push('OpenAI');
                    else missingApis.push('OpenAI');
                    
                    if (response.claude_configured) configuredApis.push('Claude');
                    else missingApis.push('Claude');
                    
                    if (response.deepseek_configured) configuredApis.push('DeepSeek');
                    else missingApis.push('DeepSeek');
                    
                    if (configuredApis.length === 4) {
                        $('#api-status').html('<div class="api-status-success">✓ All APIs configured</div>');
                    } else if (configuredApis.length > 0) {
                        $('#api-status').html('<div class="api-status-warning">⚠ Configured: ' + configuredApis.join(', ') + '</div>');
                    } else {
                        $('#api-status').html('<div class="api-status-error">✗ No APIs configured</div>');
                    }
                },
                error: function() {
                    $('#api-status').html('<div class="api-status-error">✗ Unable to check API status</div>');
                }
            });
        },

        showProgress: function(percentage, message) {
            var $progressContainer = $('#generation-progress');
            var $progressFill = $progressContainer.find('.progress-fill');
            var $progressStatus = $('#progress-status');
            
            $progressFill.css('width', percentage + '%');
            $progressStatus.text(message);
            $progressContainer.show();
        },

        hideProgress: function() {
            $('#generation-progress').hide();
        },

        showResult: function(result) {
            var $resultsContainer = $('#generation-results');
            var $resultsContent = $('#results-content');
            
            var resultClass = result.success ? 'success' : 'error';
            var resultIcon = result.success ? '✓' : '✗';
            
            var resultHtml = '<div class="generation-result ' + resultClass + '">';
            resultHtml += '<div class="generation-result-title">' + resultIcon + ' ' + result.title + '</div>';
            resultHtml += '<div class="generation-result-message">' + result.message + '</div>';
            
            if (result.success && result.post_id) {
                var editUrl = autocontentAjax.admin_url + 'post.php?post=' + result.post_id + '&action=edit';
                resultHtml += '<div class="generation-result-actions" style="margin-top: 10px;">';
                resultHtml += '<a href="' + editUrl + '" class="button button-small" target="_blank">Edit Post</a>';
                resultHtml += '</div>';
            }
            
            resultHtml += '</div>';
            
            $resultsContent.append(resultHtml);
            $resultsContainer.show();
            
            // Scroll to results
            $('html, body').animate({
                scrollTop: $resultsContainer.offset().top - 100
            }, 500);
        },

        clearResults: function() {
            $('#results-content').empty();
            $('#generation-results').hide();
        },

        showNotification: function(message, type) {
            var notificationClass = 'autocontent-notification ' + type;
            var $notification = $('<div class="' + notificationClass + '">' + message + '</div>');
            
            $('.autocontent-admin-container').prepend($notification);
            
            setTimeout(function() {
                $notification.fadeOut(function() {
                    $notification.remove();
                });
            }, 5000);
        }
    };

    // Initialize when document is ready
    $(document).ready(function() {
        AutoContentAdmin.init();
    });

    // Add AJAX actions for API status checking
    $(document).ready(function() {
        // Add test API connection action
        $(document).on('wp_ajax_test_api_connection', function() {
            // This will be handled by PHP AJAX handlers
        });
        
        // Add check API status action
        $(document).on('wp_ajax_check_api_status', function() {
            // This will be handled by PHP AJAX handlers
        });
    });

})(jQuery);
