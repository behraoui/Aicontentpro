<?php

class AutoContentAIPro_Admin {
    
    public function __construct() {
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_scripts'));
    }
    
    public function add_admin_menu() {
        add_menu_page(
            __('AutoContent AI Pro', 'autocontent-ai-pro'),
            __('AutoContent AI', 'autocontent-ai-pro'),
            'manage_options',
            'autocontent-ai-pro',
            array($this, 'admin_page'),
            'dashicons-edit-large',
            30
        );
        
        add_submenu_page(
            'autocontent-ai-pro',
            __('Generate Content', 'autocontent-ai-pro'),
            __('Generate Content', 'autocontent-ai-pro'),
            'edit_posts',
            'autocontent-ai-pro',
            array($this, 'admin_page')
        );
        
        add_submenu_page(
            'autocontent-ai-pro',
            __('Settings', 'autocontent-ai-pro'),
            __('Settings', 'autocontent-ai-pro'),
            'manage_options',
            'autocontent-ai-pro-settings',
            array($this, 'settings_page')
        );
        
        add_submenu_page(
            'autocontent-ai-pro',
            __('Logs', 'autocontent-ai-pro'),
            __('Logs', 'autocontent-ai-pro'),
            'manage_options',
            'autocontent-ai-pro-logs',
            array($this, 'logs_page')
        );
    }
    
    public function enqueue_admin_scripts($hook) {
        if (strpos($hook, 'autocontent-ai-pro') === false) {
            return;
        }
        
        wp_enqueue_style(
            'autocontent-ai-pro-admin',
            AUTOCONTENT_AI_PRO_PLUGIN_URL . 'admin/css/admin-styles.css',
            array(),
            AUTOCONTENT_AI_PRO_VERSION
        );
        
        wp_enqueue_script(
            'autocontent-ai-pro-admin',
            AUTOCONTENT_AI_PRO_PLUGIN_URL . 'admin/js/admin-scripts.js',
            array('jquery'),
            AUTOCONTENT_AI_PRO_VERSION,
            true
        );
        
        wp_localize_script('autocontent-ai-pro-admin', 'autocontentAjax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('autocontent_ai_pro_nonce'),
            'strings' => array(
                'generating' => __('Generating content...', 'autocontent-ai-pro'),
                'success' => __('Content generated successfully!', 'autocontent-ai-pro'),
                'error' => __('An error occurred while generating content.', 'autocontent-ai-pro')
            )
        ));
    }
    
    public function admin_page() {
        include AUTOCONTENT_AI_PRO_PLUGIN_PATH . 'admin/views/admin-page.php';
    }
    
    public function settings_page() {
        include AUTOCONTENT_AI_PRO_PLUGIN_PATH . 'admin/views/settings-page.php';
    }
    
    public function logs_page() {
        $logger = new AutoContentAIPro_Logger();
        $logs = $logger->get_logs(50);
        
        echo '<div class="wrap">';
        echo '<h1>' . __('AutoContent AI Pro - Logs', 'autocontent-ai-pro') . '</h1>';
        echo '<div class="autocontent-logs-container">';
        
        if (empty($logs)) {
            echo '<p>' . __('No logs found.', 'autocontent-ai-pro') . '</p>';
        } else {
            echo '<table class="wp-list-table widefat fixed striped">';
            echo '<thead><tr>';
            echo '<th>' . __('Timestamp', 'autocontent-ai-pro') . '</th>';
            echo '<th>' . __('Action', 'autocontent-ai-pro') . '</th>';
            echo '<th>' . __('Message', 'autocontent-ai-pro') . '</th>';
            echo '<th>' . __('Status', 'autocontent-ai-pro') . '</th>';
            echo '</tr></thead>';
            echo '<tbody>';
            
            foreach ($logs as $log) {
                echo '<tr>';
                echo '<td>' . esc_html($log->timestamp) . '</td>';
                echo '<td>' . esc_html($log->action) . '</td>';
                echo '<td>' . esc_html($log->message) . '</td>';
                echo '<td><span class="status-' . esc_attr($log->status) . '">' . esc_html($log->status) . '</span></td>';
                echo '</tr>';
            }
            
            echo '</tbody>';
            echo '</table>';
        }
        
        echo '</div>';
        echo '</div>';
    }
}
