<?php
if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="wrap">
    <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
    
    <div class="autocontent-admin-container">
        <div class="autocontent-main-content">
            <!-- Single Article Generation -->
            <div class="autocontent-card">
                <h2><?php _e('Generate Single Article', 'autocontent-ai-pro'); ?></h2>
                <form id="single-article-form" class="autocontent-form">
                    <table class="form-table">
                        <tr>
                            <th scope="row">
                                <label for="topic"><?php _e('Topic/Keywords', 'autocontent-ai-pro'); ?></label>
                            </th>
                            <td>
                                <input type="text" id="topic" name="topic" class="regular-text" required 
                                       placeholder="<?php esc_attr_e('Enter topic or keywords...', 'autocontent-ai-pro'); ?>" />
                                <p class="description"><?php _e('Enter the main topic or keywords for the article.', 'autocontent-ai-pro'); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="focus_keyword"><?php _e('Focus Keyword', 'autocontent-ai-pro'); ?></label>
                            </th>
                            <td>
                                <input type="text" id="focus_keyword" name="focus_keyword" class="regular-text" required 
                                       placeholder="<?php esc_attr_e('Enter focus keyword...', 'autocontent-ai-pro'); ?>" />
                                <p class="description"><?php _e('The primary keyword for SEO optimization.', 'autocontent-ai-pro'); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="publish_status"><?php _e('Publish Status', 'autocontent-ai-pro'); ?></label>
                            </th>
                            <td>
                                <select id="publish_status" name="publish_status">
                                    <option value="draft" <?php selected(get_option('autocontent_ai_pro_default_publish_status', 'draft'), 'draft'); ?>>
                                        <?php _e('Save as Draft', 'autocontent-ai-pro'); ?>
                                    </option>
                                    <option value="publish" <?php selected(get_option('autocontent_ai_pro_default_publish_status', 'draft'), 'publish'); ?>>
                                        <?php _e('Publish Immediately', 'autocontent-ai-pro'); ?>
                                    </option>
                                </select>
                            </td>
                        </tr>
                    </table>
                    
                    <p class="submit">
                        <button type="submit" class="button button-primary">
                            <span class="dashicons dashicons-admin-post"></span>
                            <?php _e('Generate Article', 'autocontent-ai-pro'); ?>
                        </button>
                    </p>
                </form>
            </div>
            
            <!-- Batch Generation -->
            <div class="autocontent-card">
                <h2><?php _e('Batch Generate Articles', 'autocontent-ai-pro'); ?></h2>
                <form id="batch-articles-form" class="autocontent-form">
                    <table class="form-table">
                        <tr>
                            <th scope="row">
                                <label for="keyword_list"><?php _e('Keywords List', 'autocontent-ai-pro'); ?></label>
                            </th>
                            <td>
                                <textarea id="keyword_list" name="keyword_list" rows="5" class="large-text" required 
                                          placeholder="<?php esc_attr_e('Enter one keyword per line...', 'autocontent-ai-pro'); ?>"></textarea>
                                <p class="description"><?php _e('Enter one keyword per line. Each keyword will be used to generate a separate article.', 'autocontent-ai-pro'); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="batch_publish_status"><?php _e('Publish Status', 'autocontent-ai-pro'); ?></label>
                            </th>
                            <td>
                                <select id="batch_publish_status" name="batch_publish_status">
                                    <option value="draft" <?php selected(get_option('autocontent_ai_pro_default_publish_status', 'draft'), 'draft'); ?>>
                                        <?php _e('Save as Draft', 'autocontent-ai-pro'); ?>
                                    </option>
                                    <option value="publish" <?php selected(get_option('autocontent_ai_pro_default_publish_status', 'draft'), 'publish'); ?>>
                                        <?php _e('Publish Immediately', 'autocontent-ai-pro'); ?>
                                    </option>
                                </select>
                            </td>
                        </tr>
                    </table>
                    
                    <p class="submit">
                        <button type="submit" class="button button-primary">
                            <span class="dashicons dashicons-admin-page"></span>
                            <?php _e('Generate Batch Articles', 'autocontent-ai-pro'); ?>
                        </button>
                    </p>
                </form>
            </div>
            
            <!-- Progress and Results -->
            <div id="generation-progress" class="autocontent-card" style="display: none;">
                <h2><?php _e('Generation Progress', 'autocontent-ai-pro'); ?></h2>
                <div class="autocontent-progress-bar">
                    <div class="progress-fill" style="width: 0%;"></div>
                </div>
                <div id="progress-status"></div>
            </div>
            
            <div id="generation-results" class="autocontent-card" style="display: none;">
                <h2><?php _e('Generation Results', 'autocontent-ai-pro'); ?></h2>
                <div id="results-content"></div>
            </div>
        </div>
        
        <!-- Sidebar -->
        <div class="autocontent-sidebar">
            <!-- API Status -->
            <div class="autocontent-card">
                <h3><?php _e('API Status', 'autocontent-ai-pro'); ?></h3>
                <div id="api-status">
                    <p><?php _e('Checking API connection...', 'autocontent-ai-pro'); ?></p>
                </div>
                <button type="button" id="test-api" class="button button-secondary">
                    <?php _e('Test API Connection', 'autocontent-ai-pro'); ?>
                </button>
            </div>
            
            <!-- Quick Stats -->
            <div class="autocontent-card">
                <h3><?php _e('Quick Stats', 'autocontent-ai-pro'); ?></h3>
                <div class="autocontent-stats">
                    <?php
                    $total_posts = wp_count_posts('post');
                    $logger = new AutoContentAIPro_Logger();
                    $recent_logs = $logger->get_logs_by_action('content_generation', 10);
                    $success_count = 0;
                    $error_count = 0;
                    
                    foreach ($recent_logs as $log) {
                        if ($log->status === 'success') {
                            $success_count++;
                        } elseif ($log->status === 'error') {
                            $error_count++;
                        }
                    }
                    ?>
                    
                    <div class="stat-item">
                        <span class="stat-number"><?php echo esc_html($total_posts->publish); ?></span>
                        <span class="stat-label"><?php _e('Published Posts', 'autocontent-ai-pro'); ?></span>
                    </div>
                    
                    <div class="stat-item">
                        <span class="stat-number"><?php echo esc_html($success_count); ?></span>
                        <span class="stat-label"><?php _e('Successful Generations', 'autocontent-ai-pro'); ?></span>
                    </div>
                    
                    <div class="stat-item">
                        <span class="stat-number"><?php echo esc_html($error_count); ?></span>
                        <span class="stat-label"><?php _e('Generation Errors', 'autocontent-ai-pro'); ?></span>
                    </div>
                </div>
            </div>
            
            <!-- Quick Actions -->
            <div class="autocontent-card">
                <h3><?php _e('Quick Actions', 'autocontent-ai-pro'); ?></h3>
                <div class="autocontent-quick-actions">
                    <a href="<?php echo admin_url('admin.php?page=autocontent-ai-pro-settings'); ?>" class="button button-secondary">
                        <span class="dashicons dashicons-admin-settings"></span>
                        <?php _e('Settings', 'autocontent-ai-pro'); ?>
                    </a>
                    
                    <a href="<?php echo admin_url('admin.php?page=autocontent-ai-pro-logs'); ?>" class="button button-secondary">
                        <span class="dashicons dashicons-list-view"></span>
                        <?php _e('View Logs', 'autocontent-ai-pro'); ?>
                    </a>
                    
                    <a href="<?php echo admin_url('edit.php'); ?>" class="button button-secondary">
                        <span class="dashicons dashicons-admin-post"></span>
                        <?php _e('All Posts', 'autocontent-ai-pro'); ?>
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
