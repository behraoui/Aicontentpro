<?php
if (!defined('ABSPATH')) {
    exit;
}

// Handle form submission
if (isset($_POST['submit'])) {
    check_admin_referer('autocontent_ai_pro_settings');
    
    // Save settings
    foreach ($_POST as $key => $value) {
        if (strpos($key, 'autocontent_ai_pro_') === 0) {
            update_option($key, sanitize_text_field($value));
        }
    }
    
    echo '<div class="notice notice-success is-dismissible"><p>' . __('Settings saved successfully!', 'autocontent-ai-pro') . '</p></div>';
}
?>

<div class="wrap">
    <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
    
    <form method="post" action="">
        <?php wp_nonce_field('autocontent_ai_pro_settings'); ?>
        
        <div class="autocontent-settings-container">
            <!-- API Settings -->
            <div class="autocontent-card">
                <h2><?php _e('API Settings', 'autocontent-ai-pro'); ?></h2>
                <p><?php _e('Configure your API keys and model preferences.', 'autocontent-ai-pro'); ?></p>
                
                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="openrouter_api_key"><?php _e('OpenRouter API Key', 'autocontent-ai-pro'); ?></label>
                        </th>
                        <td>
                            <input type="password" id="openrouter_api_key" name="autocontent_ai_pro_openrouter_api_key" 
                                   value="<?php echo esc_attr(get_option('autocontent_ai_pro_openrouter_api_key', '')); ?>" 
                                   class="regular-text" />
                            <p class="description">
                                <?php _e('Your OpenRouter API key for content generation.', 'autocontent-ai-pro'); ?>
                                <a href="https://openrouter.ai/" target="_blank"><?php _e('Get API Key', 'autocontent-ai-pro'); ?></a>
                            </p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">
                            <label for="openai_api_key"><?php _e('OpenAI API Key', 'autocontent-ai-pro'); ?></label>
                        </th>
                        <td>
                            <input type="password" id="openai_api_key" name="autocontent_ai_pro_openai_api_key" 
                                   value="<?php echo esc_attr(get_option('autocontent_ai_pro_openai_api_key', '')); ?>" 
                                   class="regular-text" />
                            <p class="description">
                                <?php _e('Your OpenAI API key for ChatGPT models.', 'autocontent-ai-pro'); ?>
                                <a href="https://platform.openai.com/api-keys" target="_blank"><?php _e('Get API Key', 'autocontent-ai-pro'); ?></a>
                            </p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">
                            <label for="claude_api_key"><?php _e('Claude API Key', 'autocontent-ai-pro'); ?></label>
                        </th>
                        <td>
                            <input type="password" id="claude_api_key" name="autocontent_ai_pro_claude_api_key" 
                                   value="<?php echo esc_attr(get_option('autocontent_ai_pro_claude_api_key', '')); ?>" 
                                   class="regular-text" />
                            <p class="description">
                                <?php _e('Your Anthropic API key for Claude models.', 'autocontent-ai-pro'); ?>
                                <a href="https://console.anthropic.com/" target="_blank"><?php _e('Get API Key', 'autocontent-ai-pro'); ?></a>
                            </p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">
                            <label for="deepseek_api_key"><?php _e('DeepSeek API Key', 'autocontent-ai-pro'); ?></label>
                        </th>
                        <td>
                            <input type="password" id="deepseek_api_key" name="autocontent_ai_pro_deepseek_api_key" 
                                   value="<?php echo esc_attr(get_option('autocontent_ai_pro_deepseek_api_key', '')); ?>" 
                                   class="regular-text" />
                            <p class="description">
                                <?php _e('Your DeepSeek API key for DeepSeek models.', 'autocontent-ai-pro'); ?>
                                <a href="https://platform.deepseek.com/" target="_blank"><?php _e('Get API Key', 'autocontent-ai-pro'); ?></a>
                            </p>
                        </td>
                    </tr>
                    

                    
                    <tr>
                        <th scope="row">
                            <label for="default_model"><?php _e('Default AI Model', 'autocontent-ai-pro'); ?></label>
                        </th>
                        <td>
                            <?php
                            $current_model = get_option('autocontent_ai_pro_default_model', 'gpt-4');
                            $models = array(
                                // OpenAI Models
                                'gpt-4' => 'GPT-4 (OpenAI)',
                                'gpt-4-turbo' => 'GPT-4 Turbo (OpenAI)',
                                'gpt-3.5-turbo' => 'GPT-3.5 Turbo (OpenAI)',
                                
                                // Claude Models
                                'claude-3-opus-20240229' => 'Claude 3 Opus (Anthropic)',
                                'claude-3-sonnet-20240229' => 'Claude 3 Sonnet (Anthropic)',
                                'claude-3-haiku-20240307' => 'Claude 3 Haiku (Anthropic)',
                                
                                // DeepSeek Models
                                'deepseek-chat' => 'DeepSeek Chat',
                                'deepseek-coder' => 'DeepSeek Coder',
                                
                                // OpenRouter Models
                                'openai/gpt-4' => 'GPT-4 (via OpenRouter)',
                                'openai/gpt-3.5-turbo' => 'GPT-3.5 Turbo (via OpenRouter)',
                                'anthropic/claude-2' => 'Claude 2 (via OpenRouter)',
                                'anthropic/claude-instant-v1' => 'Claude Instant (via OpenRouter)'
                            );
                            ?>
                            <select id="default_model" name="autocontent_ai_pro_default_model">
                                <?php foreach ($models as $model => $label): ?>
                                    <option value="<?php echo esc_attr($model); ?>" <?php selected($current_model, $model); ?>>
                                        <?php echo esc_html($label); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <p class="description"><?php _e('Choose the default AI model for content generation.', 'autocontent-ai-pro'); ?></p>
                        </td>
                    </tr>
                </table>
            </div>
            
            <!-- Content Settings -->
            <div class="autocontent-card">
                <h2><?php _e('Content Settings', 'autocontent-ai-pro'); ?></h2>
                <p><?php _e('Configure content generation and SEO settings.', 'autocontent-ai-pro'); ?></p>
                
                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="default_publish_status"><?php _e('Default Publish Status', 'autocontent-ai-pro'); ?></label>
                        </th>
                        <td>
                            <?php $current_status = get_option('autocontent_ai_pro_default_publish_status', 'draft'); ?>
                            <select id="default_publish_status" name="autocontent_ai_pro_default_publish_status">
                                <option value="draft" <?php selected($current_status, 'draft'); ?>><?php _e('Draft', 'autocontent-ai-pro'); ?></option>
                                <option value="publish" <?php selected($current_status, 'publish'); ?>><?php _e('Publish', 'autocontent-ai-pro'); ?></option>
                            </select>
                            <p class="description"><?php _e('Default status for generated articles.', 'autocontent-ai-pro'); ?></p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row"><?php _e('Feature Options', 'autocontent-ai-pro'); ?></th>
                        <td>
                            <fieldset>
                                <label>
                                    <input type="checkbox" name="autocontent_ai_pro_enable_images" value="1" 
                                           <?php checked(get_option('autocontent_ai_pro_enable_images', 1), 1); ?> />
                                    <?php _e('Enable automatic image generation and insertion', 'autocontent-ai-pro'); ?>
                                </label>
                                <br><br>
                                
                                <label>
                                    <input type="checkbox" name="autocontent_ai_pro_enable_seo" value="1" 
                                           <?php checked(get_option('autocontent_ai_pro_enable_seo', 1), 1); ?> />
                                    <?php _e('Enable SEO optimization features', 'autocontent-ai-pro'); ?>
                                </label>
                            </fieldset>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">
                            <label for="internal_links_count"><?php _e('Internal Links Count', 'autocontent-ai-pro'); ?></label>
                        </th>
                        <td>
                            <input type="number" id="internal_links_count" name="autocontent_ai_pro_internal_links_count" 
                                   value="<?php echo esc_attr(get_option('autocontent_ai_pro_internal_links_count', 2)); ?>" 
                                   min="0" max="10" />
                            <p class="description"><?php _e('Number of internal links to add to each article.', 'autocontent-ai-pro'); ?></p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">
                            <label for="external_links_count"><?php _e('External Links Count', 'autocontent-ai-pro'); ?></label>
                        </th>
                        <td>
                            <input type="number" id="external_links_count" name="autocontent_ai_pro_external_links_count" 
                                   value="<?php echo esc_attr(get_option('autocontent_ai_pro_external_links_count', 3)); ?>" 
                                   min="0" max="10" />
                            <p class="description"><?php _e('Number of external links to add to each article.', 'autocontent-ai-pro'); ?></p>
                        </td>
                    </tr>
                </table>
            </div>
            
            <!-- Plugin Information -->
            <div class="autocontent-card">
                <h2><?php _e('Plugin Information', 'autocontent-ai-pro'); ?></h2>
                
                <table class="form-table">
                    <tr>
                        <th scope="row"><?php _e('Plugin Version', 'autocontent-ai-pro'); ?></th>
                        <td><?php echo esc_html(AUTOCONTENT_AI_PRO_VERSION); ?></td>
                    </tr>
                    
                    <tr>
                        <th scope="row"><?php _e('WordPress Version', 'autocontent-ai-pro'); ?></th>
                        <td><?php echo esc_html(get_bloginfo('version')); ?></td>
                    </tr>
                    
                    <tr>
                        <th scope="row"><?php _e('PHP Version', 'autocontent-ai-pro'); ?></th>
                        <td><?php echo esc_html(PHP_VERSION); ?></td>
                    </tr>
                    
                    <tr>
                        <th scope="row"><?php _e('SEO Plugin Detected', 'autocontent-ai-pro'); ?></th>
                        <td>
                            <?php
                            if (class_exists('RankMath')) {
                                echo '<span class="autocontent-status-success">RankMath</span>';
                            } elseif (class_exists('WPSEO_Options')) {
                                echo '<span class="autocontent-status-success">Yoast SEO</span>';
                            } else {
                                echo '<span class="autocontent-status-warning">' . __('None detected', 'autocontent-ai-pro') . '</span>';
                            }
                            ?>
                        </td>
                    </tr>
                </table>
            </div>
        </div>
        
        <?php submit_button(__('Save Settings', 'autocontent-ai-pro')); ?>
    </form>
</div>
