<?php

class AutoContentAIPro_Settings {
    
    public function __construct() {
        add_action('admin_init', array($this, 'init_settings'));
    }
    
    public function init_settings() {
        register_setting(
            'autocontent_ai_pro_settings',
            'autocontent_ai_pro_openrouter_api_key',
            array('sanitize_callback' => 'sanitize_text_field')
        );
        
        register_setting(
            'autocontent_ai_pro_settings',
            'autocontent_ai_pro_openai_api_key',
            array('sanitize_callback' => 'sanitize_text_field')
        );
        
        register_setting(
            'autocontent_ai_pro_settings',
            'autocontent_ai_pro_claude_api_key',
            array('sanitize_callback' => 'sanitize_text_field')
        );
        
        register_setting(
            'autocontent_ai_pro_settings',
            'autocontent_ai_pro_deepseek_api_key',
            array('sanitize_callback' => 'sanitize_text_field')
        );
        

        
        register_setting(
            'autocontent_ai_pro_settings',
            'autocontent_ai_pro_default_model',
            array('sanitize_callback' => 'sanitize_text_field')
        );
        
        register_setting(
            'autocontent_ai_pro_settings',
            'autocontent_ai_pro_default_publish_status',
            array('sanitize_callback' => 'sanitize_text_field')
        );
        
        register_setting(
            'autocontent_ai_pro_settings',
            'autocontent_ai_pro_enable_images',
            array('sanitize_callback' => 'absint')
        );
        
        register_setting(
            'autocontent_ai_pro_settings',
            'autocontent_ai_pro_enable_seo',
            array('sanitize_callback' => 'absint')
        );
        
        register_setting(
            'autocontent_ai_pro_settings',
            'autocontent_ai_pro_internal_links_count',
            array('sanitize_callback' => 'absint')
        );
        
        register_setting(
            'autocontent_ai_pro_settings',
            'autocontent_ai_pro_external_links_count',
            array('sanitize_callback' => 'absint')
        );
        
        // API Settings Section
        add_settings_section(
            'autocontent_ai_pro_api_settings',
            __('API Settings', 'autocontent-ai-pro'),
            array($this, 'api_settings_callback'),
            'autocontent_ai_pro_settings'
        );
        
        add_settings_field(
            'openrouter_api_key',
            __('OpenRouter API Key', 'autocontent-ai-pro'),
            array($this, 'openrouter_api_key_callback'),
            'autocontent_ai_pro_settings',
            'autocontent_ai_pro_api_settings'
        );
        
        add_settings_field(
            'openai_api_key',
            __('OpenAI API Key', 'autocontent-ai-pro'),
            array($this, 'openai_api_key_callback'),
            'autocontent_ai_pro_settings',
            'autocontent_ai_pro_api_settings'
        );
        
        add_settings_field(
            'claude_api_key',
            __('Claude API Key', 'autocontent-ai-pro'),
            array($this, 'claude_api_key_callback'),
            'autocontent_ai_pro_settings',
            'autocontent_ai_pro_api_settings'
        );
        
        add_settings_field(
            'deepseek_api_key',
            __('DeepSeek API Key', 'autocontent-ai-pro'),
            array($this, 'deepseek_api_key_callback'),
            'autocontent_ai_pro_settings',
            'autocontent_ai_pro_api_settings'
        );
        

        
        add_settings_field(
            'default_model',
            __('Default AI Model', 'autocontent-ai-pro'),
            array($this, 'default_model_callback'),
            'autocontent_ai_pro_settings',
            'autocontent_ai_pro_api_settings'
        );
        
        // Content Settings Section
        add_settings_section(
            'autocontent_ai_pro_content_settings',
            __('Content Settings', 'autocontent-ai-pro'),
            array($this, 'content_settings_callback'),
            'autocontent_ai_pro_settings'
        );
        
        add_settings_field(
            'default_publish_status',
            __('Default Publish Status', 'autocontent-ai-pro'),
            array($this, 'default_publish_status_callback'),
            'autocontent_ai_pro_settings',
            'autocontent_ai_pro_content_settings'
        );
        
        add_settings_field(
            'enable_images',
            __('Enable Image Generation', 'autocontent-ai-pro'),
            array($this, 'enable_images_callback'),
            'autocontent_ai_pro_settings',
            'autocontent_ai_pro_content_settings'
        );
        
        add_settings_field(
            'enable_seo',
            __('Enable SEO Optimization', 'autocontent-ai-pro'),
            array($this, 'enable_seo_callback'),
            'autocontent_ai_pro_settings',
            'autocontent_ai_pro_content_settings'
        );
        
        add_settings_field(
            'internal_links_count',
            __('Internal Links Count', 'autocontent-ai-pro'),
            array($this, 'internal_links_count_callback'),
            'autocontent_ai_pro_settings',
            'autocontent_ai_pro_content_settings'
        );
        
        add_settings_field(
            'external_links_count',
            __('External Links Count', 'autocontent-ai-pro'),
            array($this, 'external_links_count_callback'),
            'autocontent_ai_pro_settings',
            'autocontent_ai_pro_content_settings'
        );
    }
    
    public function api_settings_callback() {
        echo '<p>' . __('Configure your API keys and model preferences.', 'autocontent-ai-pro') . '</p>';
    }
    
    public function content_settings_callback() {
        echo '<p>' . __('Configure content generation and SEO settings.', 'autocontent-ai-pro') . '</p>';
    }
    
    public function openrouter_api_key_callback() {
        $value = get_option('autocontent_ai_pro_openrouter_api_key', '');
        echo '<input type="password" id="openrouter_api_key" name="autocontent_ai_pro_openrouter_api_key" value="' . esc_attr($value) . '" class="regular-text" />';
        echo '<p class="description">' . __('Your OpenRouter API key for content generation.', 'autocontent-ai-pro') . '</p>';
    }
    
    public function openai_api_key_callback() {
        $value = get_option('autocontent_ai_pro_openai_api_key', '');
        echo '<input type="password" id="openai_api_key" name="autocontent_ai_pro_openai_api_key" value="' . esc_attr($value) . '" class="regular-text" />';
        echo '<p class="description">' . __('Your OpenAI API key for ChatGPT models.', 'autocontent-ai-pro') . '</p>';
    }
    
    public function claude_api_key_callback() {
        $value = get_option('autocontent_ai_pro_claude_api_key', '');
        echo '<input type="password" id="claude_api_key" name="autocontent_ai_pro_claude_api_key" value="' . esc_attr($value) . '" class="regular-text" />';
        echo '<p class="description">' . __('Your Anthropic API key for Claude models.', 'autocontent-ai-pro') . '</p>';
    }
    
    public function deepseek_api_key_callback() {
        $value = get_option('autocontent_ai_pro_deepseek_api_key', '');
        echo '<input type="password" id="deepseek_api_key" name="autocontent_ai_pro_deepseek_api_key" value="' . esc_attr($value) . '" class="regular-text" />';
        echo '<p class="description">' . __('Your DeepSeek API key for DeepSeek models.', 'autocontent-ai-pro') . '</p>';
    }
    

    
    public function default_model_callback() {
        $value = get_option('autocontent_ai_pro_default_model', 'openai/gpt-4');
        $models = array(
            // OpenAI Models
            'gpt-4' => 'GPT-4 (OpenAI)',
            'gpt-4-turbo' => 'GPT-4 Turbo (OpenAI)',
            'gpt-3.5-turbo' => 'GPT-3.5 Turbo (OpenAI)',
            
            // Claude Models
            'claude-3-opus-20240229' => 'Claude 3 Opus (Anthropic)',
            'claude-3-sonnet-20240229' => 'Claude 3 Sonnet (Anthropic)',
            'claude-3-haiku-20240307' => 'Claude 3 Haiku (Anthropic)',
            
            // DeepSeek Models
            'deepseek-chat' => 'DeepSeek Chat',
            'deepseek-coder' => 'DeepSeek Coder',
            
            // OpenRouter Models
            'openai/gpt-4' => 'GPT-4 (via OpenRouter)',
            'openai/gpt-3.5-turbo' => 'GPT-3.5 Turbo (via OpenRouter)',
            'anthropic/claude-2' => 'Claude 2 (via OpenRouter)',
            'anthropic/claude-instant-v1' => 'Claude Instant (via OpenRouter)'
        );
        
        echo '<select id="default_model" name="autocontent_ai_pro_default_model">';
        foreach ($models as $model => $label) {
            echo '<option value="' . esc_attr($model) . '"' . selected($value, $model, false) . '>' . esc_html($label) . '</option>';
        }
        echo '</select>';
    }
    
    public function default_publish_status_callback() {
        $value = get_option('autocontent_ai_pro_default_publish_status', 'draft');
        $statuses = array(
            'draft' => __('Draft', 'autocontent-ai-pro'),
            'publish' => __('Publish', 'autocontent-ai-pro')
        );
        
        echo '<select id="default_publish_status" name="autocontent_ai_pro_default_publish_status">';
        foreach ($statuses as $status => $label) {
            echo '<option value="' . esc_attr($status) . '"' . selected($value, $status, false) . '>' . esc_html($label) . '</option>';
        }
        echo '</select>';
    }
    
    public function enable_images_callback() {
        $value = get_option('autocontent_ai_pro_enable_images', 1);
        echo '<input type="checkbox" id="enable_images" name="autocontent_ai_pro_enable_images" value="1"' . checked($value, 1, false) . ' />';
        echo '<label for="enable_images">' . __('Enable automatic image generation and insertion', 'autocontent-ai-pro') . '</label>';
    }
    
    public function enable_seo_callback() {
        $value = get_option('autocontent_ai_pro_enable_seo', 1);
        echo '<input type="checkbox" id="enable_seo" name="autocontent_ai_pro_enable_seo" value="1"' . checked($value, 1, false) . ' />';
        echo '<label for="enable_seo">' . __('Enable SEO optimization features', 'autocontent-ai-pro') . '</label>';
    }
    
    public function internal_links_count_callback() {
        $value = get_option('autocontent_ai_pro_internal_links_count', 2);
        echo '<input type="number" id="internal_links_count" name="autocontent_ai_pro_internal_links_count" value="' . esc_attr($value) . '" min="0" max="10" />';
        echo '<p class="description">' . __('Number of internal links to add to each article.', 'autocontent-ai-pro') . '</p>';
    }
    
    public function external_links_count_callback() {
        $value = get_option('autocontent_ai_pro_external_links_count', 3);
        echo '<input type="number" id="external_links_count" name="autocontent_ai_pro_external_links_count" value="' . esc_attr($value) . '" min="0" max="10" />';
        echo '<p class="description">' . __('Number of external links to add to each article.', 'autocontent-ai-pro') . '</p>';
    }
}
